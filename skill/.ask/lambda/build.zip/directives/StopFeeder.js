"use strict";

module.exports = {
    build: function (token) {
        return {
            type: "CustomInterfaceController.StopEventHandler",
            token: token
        };
    }
}